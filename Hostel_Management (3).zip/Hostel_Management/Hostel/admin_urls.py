# from django.urls import path

# from Hostel.admin_views import IndexView,HostelsView,NewHostelsView,NewUsersView,UsersView,ApproveView,RejectView

# urlpatterns =[

#     path('',IndexView.as_view()),
#     path('hostels',HostelsView.as_view()),
#     path('newhostels',NewHostelsView.as_view()),
#     path('users',UsersView.as_view()),
#     path('newusers',NewUsersView.as_view()),
#     path('approve',ApproveView.as_view()),
#     path('reject',RejectView.as_view()),
# ]


# def urls():
#     return (urlpatterns,'admin','admin')